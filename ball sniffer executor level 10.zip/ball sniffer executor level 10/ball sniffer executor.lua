-- You can remove the admin loaded say request so people have no idea

local args = {
    [1] = "Admin loaded. Check console for commands",
    [2] = "All"
}

game:GetService("ReplicatedStorage").DefaultChatSystemChatEvents.SayMessageRequest:FireServer(unpack(args))

-------------------------------------------------------------------------------------------------------------------------

-- Gui to Lua
-- Version: 3.2

-- Instances:

local ScreenGui = Instance.new("ScreenGui")
local Frame = Instance.new("Frame")
local TextLabel = Instance.new("TextLabel")
local TextButton = Instance.new("TextButton")

--Properties:

ScreenGui.Parent = game.Players.LocalPlayer:WaitForChild("PlayerGui")
ScreenGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling

Frame.Parent = ScreenGui
Frame.BackgroundColor3 = Color3.fromRGB(40, 40, 40)
Frame.Position = UDim2.new(0.328343987, 0, 0.06942489, 0)
Frame.Size = UDim2.new(0, 799, 0, 696)

TextLabel.Parent = Frame
TextLabel.BackgroundColor3 = Color3.fromRGB(50, 50, 50)
TextLabel.BorderSizePixel = 0
TextLabel.Position = UDim2.new(0.0681877658, 0, 0.143724859, 0)
TextLabel.Size = UDim2.new(0, 690, 0, 495)
TextLabel.Font = Enum.Font.SourceSans
TextLabel.Text = "Thank you for using this script.Click the X button so this gui disappears"
TextLabel.TextColor3 = Color3.fromRGB(0, 0, 0)
TextLabel.TextScaled = true
TextLabel.TextSize = 14.000
TextLabel.TextWrapped = true

TextButton.Parent = Frame
TextButton.BackgroundColor3 = Color3.fromRGB(255, 0, 0)
TextButton.Position = UDim2.new(0.861445487, 0, 0, 0)
TextButton.Size = UDim2.new(0, 110, 0, 100)
TextButton.Font = Enum.Font.SourceSans
TextButton.Text = "X"
TextButton.TextColor3 = Color3.fromRGB(0, 0, 0)
TextButton.TextSize = 50.000

-- Scripts:

local function PVIRUO_fake_script() -- TextButton.LocalScript 
	local script = Instance.new('LocalScript', TextButton)

	script.Parent.MouseButton1Click:Connect(function()
		script.Parent.Parent.Visible = false
	end)
	
end
coroutine.wrap(PVIRUO_fake_script)()





print(".sit")
print(".fastspeed")
print(".normalspeed")
print(".infyield")
print(".highjumppower")
print(".classicjumppower")
print(".highhipheight")
print(".normalhipheight")
print(".checkplayersname")
print(".checkworkspace")
print(".highfov")
print(".normalfov")
print(".infjump")
print(".fullbright")
print(".stealitems (CLIENT)")


local Player = game.Players.LocalPlayer

Player.Chatted:connect(function(cht)
if cht:match(".sit") then
game.Players.LocalPlayer.Character.Humanoid.Sit = true
end
end)

local Player = game.Players.LocalPlayer

Player.Chatted:connect(function(cht)
if cht:match(".fastspeed") then
game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = 100
end
end)

Player.Chatted:connect(function(cht)
if cht:match(".normalspeed") then
game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = 16
end
end)

Player.Chatted:connect(function(cht)
if cht:match(".infyield") then
loadstring(game:HttpGet('https://raw.githubusercontent.com/EdgeIY/infiniteyield/master/source'))()
end
end)

Player.Chatted:connect(function(cht)
if cht:match(".highjumppower") then
game.Players.LocalPlayer.Character.Humanoid.JumpPower = 150
end
end)

Player.Chatted:connect(function(cht)
if cht:match(".classicjumppower") then
game.Players.LocalPlayer.Character.Humanoid.JumpPower = 50
end
end)

Player.Chatted:connect(function(cht)
if cht:match(".highhipheight") then
game.Players.LocalPlayer.Character.Humanoid.HipHeight = 5
end
end)

Player.Chatted:connect(function(cht)
if cht:match(".normalhipheight") then
game.Players.LocalPlayer.Character.Humanoid.HipHeight = 0
end
end)

Player.Chatted:connect(function(cht)
if cht:match(".checkplayersname") then
for i,v in pairs(game.Players:GetChildren()) do
print(v.Name)
end
end
end)

Player.Chatted:connect(function(cht)
if cht:match(".checkworkspace") then
for i,v in pairs(game.Workspace:GetChildren()) do
print(v.Name)
end
end
end)

Player.Chatted:connect(function(cht)
if cht:match(".highfov") then
game.Workspace.Camera.FieldOfView = 90
end
end)

Player.Chatted:connect(function(cht)
if cht:match(".normalfov") then
game.Workspace.Camera.FieldOfView = 70
end
end)

Player.Chatted:connect(function(cht)
if cht:match(".infjump") then
local InfiniteJumpEnabled = true
game:GetService("UserInputService").JumpRequest:connect(function()
	if InfiniteJumpEnabled then
		game:GetService"Players".LocalPlayer.Character:FindFirstChildOfClass'Humanoid':ChangeState("Jumping")
	end
end)
end
end)

Player.Chatted:connect(function(cht)
if cht:match(".fullbright") then
local Light = game:GetService("Lighting")
 
function dofullbright()
Light.Ambient = Color3.new(1, 1, 1)
Light.ColorShift_Bottom = Color3.new(1, 1, 1)
Light.ColorShift_Top = Color3.new(1, 1, 1)
end
 
dofullbright()
 
Light.LightingChanged:Connect(dofullbright)
end
end)

Player.Chatted:connect(function(cht)
if cht:match(".nolegs") then
game.Players.LocalPlayer.Character.Humanoid.HipHeight = -2
end
end)

Player.Chatted:connect(function(cht)
if cht:match(".superhuman") then
game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = 120
game.Players.LocalPlayer.Character.Humanoid.JumpPower = 120
end
end)

Player.Chatted:connect(function(cht)
if cht:match(".human") then
game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = 16
game.Players.LocalPlayer.Character.Humanoid.JumpPower = 50
end
end)

Player.Chatted:connect(function(cht)
if cht:match(".stealitems") then
for i,v in pairs(v.Backpack:GetChildren()) do
local clone = v:Clone
clone.Parent = game.Players.LocalPlayer.Backpack
end
end)